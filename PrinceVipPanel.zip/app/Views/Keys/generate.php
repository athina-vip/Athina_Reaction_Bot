<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .generate-container {
        padding: 20px;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .generate-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
    }
    
    .generate-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .generate-subtitle {
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    .generate-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        width: 100%;
        max-width: 600px;
    }
    
    .generate-card-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .generate-card-title {
        font-size: 1.5rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        margin: 0;
    }
    
    .generate-card-title i {
        margin-right: 12px;
        font-size: 1.8rem;
    }
    
    .back-btn {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.3);
        color: white;
        padding: 10px 15px;
        border-radius: 12px;
        text-decoration: none;
        transition: all 0.3s ease;
        backdrop-filter: blur(10px);
    }
    
    .back-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        border-color: rgba(255, 255, 255, 0.5);
        color: white;
        transform: scale(1.05);
    }
    
    .generate-card-body {
        padding: 40px 30px;
    }
    
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-label {
        font-weight: 600;
        color: #374151;
        margin-bottom: 8px;
        display: block;
    }
    
    .form-control, .form-select {
        width: 100%;
        padding: 15px 20px;
        border: 2px solid #E5E7EB;
        border-radius: 12px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #F9FAFB;
    }
    
    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: #8B5CF6;
        background: white;
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
    }
    
    .form-check {
        margin-bottom: 20px;
    }
    
    .form-check-input {
        width: 20px;
        height: 20px;
        margin-right: 10px;
        accent-color: #8B5CF6;
    }
    
    .form-check-label {
        font-weight: 500;
        color: #374151;
    }
    
    .generate-btn {
        width: 100%;
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 18px;
        border-radius: 12px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }
    
    .generate-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(139, 92, 246, 0.3);
    }
    
    .success-alert {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
        padding: 25px;
        border-radius: 16px;
        margin-bottom: 25px;
        box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
    }
    
    .success-alert h4 {
        margin-bottom: 15px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .key-display {
        background: rgba(255, 255, 255, 0.1);
        padding: 15px;
        border-radius: 12px;
        margin: 15px 0;
        font-family: 'Courier New', monospace;
        font-size: 1.1rem;
        word-break: break-all;
    }
    
    .copy-btn {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.3);
        color: white;
        padding: 8px 12px;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-left: 10px;
    }
    
    .copy-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: scale(1.05);
    }
    
    .key-sensi {
        filter: blur(3px);
        transition: filter 0.3s ease;
    }
    
    .key-sensi.revealed {
        filter: none;
    }
    
    .error-message {
        color: #EF4444;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
    }
    
    .estimation-input {
        background: #F3F4F6 !important;
        color: #6B7280;
        font-weight: 600;
    }
    
    @media (max-width: 768px) {
        .generate-container {
            padding: 15px;
        }
        
        .generate-title {
            font-size: 2rem;
        }
        
        .generate-card-body {
            padding: 25px 20px;
        }
        
        .generate-card-header {
            flex-direction: column;
            gap: 15px;
            text-align: center;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="generate-container">
    <div class="w-100">
        <!-- Generate Header -->
        <div class="generate-header">
            <h1 class="generate-title">Generate License Key</h1>
            <p class="generate-subtitle">Create new license keys for your applications</p>
        </div>
        
        <!-- Status Messages -->
        <div class="row">
            <div class="col-12">
                <?= $this->include('Layout/msgStatus') ?>
            </div>
        </div>
        
        <!-- Success Alert -->
        <?php if (session()->getFlashdata('user_key')) : ?>
            <div class="success-alert">
                <h4>
                    <i class="bi bi-check-circle-fill"></i>
                    License Generated Successfully!
                </h4>
                <div class="row">
                    <div class="col-md-6">
                        <strong>Game:</strong> <?= session()->getFlashdata('game') ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Duration:</strong> <?= session()->getFlashdata('duration') ?> Hours
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6">
                        <strong>Max Devices:</strong> <?= session()->getFlashdata('max_devices') ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Status:</strong> <span class="badge bg-light text-success">Active</span>
                    </div>
                </div>
                <div class="key-display">
                    <strong>License Key:</strong>
                    <span class="key-sensi" id="licenseKey"><?= session()->getFlashdata('user_key') ?></span>
                    <button class="copy-btn" onclick="copyText()" title="Copy Key">
                        <i class="bi bi-clipboard"></i>
                    </button>
                </div>
                <small>
                    <i class="bi bi-info-circle"></i>
                    Duration will start when license is first used.
                </small>
            </div>
        <?php endif; ?>
        
        <!-- Generate Form -->
        <div class="generate-card">
            <div class="generate-card-header">
                <h2 class="generate-card-title">
                    <i class="bi bi-plus-circle-fill"></i>
                    Create License
                </h2>
                <a class="back-btn" href="<?= site_url('keys') ?>">
                    <i class="bi bi-arrow-left"></i>
                </a>
            </div>
            
            <div class="generate-card-body">
                <?= form_open() ?>
                
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="game" class="form-label">Game</label>
                            <?= form_dropdown(['class' => 'form-select', 'name' => 'game', 'id' => 'game'], $game, old('game') ?: '') ?>
                            <?php if ($validation->hasError('game')) : ?>
                                <span class="error-message"><?= $validation->getError('game') ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="max_devices" class="form-label">Max Devices</label>
                            <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="1" value="<?= old('max_devices') ?: 1 ?>" min="1">
                            <?php if ($validation->hasError('max_devices')) : ?>
                                <span class="error-message"><?= $validation->getError('max_devices') ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="duration" class="form-label">Duration</label>
                    <?= form_dropdown(['class' => 'form-select', 'name' => 'duration', 'id' => 'duration'], $duration, old('duration') ?: '') ?>
                    <?php if ($validation->hasError('duration')) : ?>
                        <span class="error-message"><?= $validation->getError('duration') ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="check" onchange="fupi(this)" id="check">
                    <label class="form-check-label" for="check">
                        Use Custom Key
                    </label>
                </div>
                
                <div class="form-group" id="customKeyGroup" style="display: none;">
                    <label for="custom" id="cuslabel" class="form-label">Custom License Key</label>
                    <input type="text" minlength="4" maxlength="16" name="cuslicense" class="form-control" id="custom" placeholder="Enter custom key">
                </div>
                
                <div class="form-group" id="bulkKeyGroup">
                    <label for="hulala" id="labula" class="form-label">Bulk Generation</label>
                    <select class="form-select" id="hulala" name="loopcount">
                        <option value="1">1 Key</option>
                        <option value="5">5 Keys</option>
                        <option value="10">10 Keys</option>
                        <option value="25">25 Keys</option>
                        <option value="50">50 Keys</option>
                        <option value="100">100 Keys</option>
                    </select>
                </div>
                
                <input type="hidden" id="textinput" name="custominput" value="auto">
                
                <div class="form-group">
                    <label for="estimation" class="form-label">Cost Estimation</label>
                    <input type="text" id="estimation" class="form-control estimation-input" placeholder="Your order will total" readonly>
                </div>
                
                <button type="submit" class="generate-btn">
                    <i class="bi bi-key-fill"></i>
                    Generate License
                </button>
                
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>
<!-- Hidden textarea for copy functionality -->
<textarea id="mytext" style="position: absolute; left: -9999px; opacity: 0;"><?= session()->getFlashdata('user_key') ?></textarea>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var price = JSON.parse('<?= $price ?>');
        getPrice(price);
        
        // When selected
        $("#max_devices, #duration, #game").change(function() {
            getPrice(price);
        });
        
        // Initialize custom key group as hidden
        $("#customKeyGroup").hide();
        
        // try to get price
        function getPrice(price) {
            var price = price;
            var device = $("#max_devices").val();
            var durate = $("#duration").val();
            var gprice = price[durate];
            if (gprice != NaN) {
                var result = (device * gprice);
                $("#estimation").val('₹' + result);
            } else {
                $("#estimation").val('Estimation error');
            }
        }
    });

    function fupi(obj) {
        if($(obj).is(":checked")){
            // Show custom key input
            $("#customKeyGroup").slideDown(300);
            $("#bulkKeyGroup").slideUp(300);
            document.getElementById("textinput").value = "custom";
            
            // Reset bulk selection
            $('#hulala option').prop('selected', function() {
                return this.defaultSelected;
            });
        } else {
            // Show bulk key selection
            $("#customKeyGroup").slideUp(300);
            $("#bulkKeyGroup").slideDown(300);
            document.getElementById("textinput").value = "auto";
        }
    }
    
    function copyText() {
        var mytext = document.getElementById("mytext"); 
        mytext.select(); // Select Text Field
        document.execCommand("copy");  // Copy Text
        
        // Show success feedback
        const copyBtn = document.querySelector('.copy-btn');
        const originalHTML = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="bi bi-check"></i>';
        copyBtn.style.background = 'rgba(16, 185, 129, 0.3)';
        
        setTimeout(() => {
            copyBtn.innerHTML = originalHTML;
            copyBtn.style.background = 'rgba(255, 255, 255, 0.2)';
        }, 2000);
    }
</script>
<?= $this->endSection() ?>