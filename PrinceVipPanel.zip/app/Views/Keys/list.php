<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .keys-container {
        padding: 20px;
        min-height: 100vh;
    }
    
    .keys-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
    }
    
    .keys-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .keys-subtitle {
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    .keys-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        margin-bottom: 30px;
    }
    
    .keys-card-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .keys-card-title {
        font-size: 1.5rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        margin: 0;
    }
    
    .keys-card-title i {
        margin-right: 12px;
        font-size: 1.8rem;
    }
    
    .header-actions {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .eye-toggle-btn {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.3);
        color: white;
        padding: 10px 15px;
        border-radius: 12px;
        transition: all 0.3s ease;
        backdrop-filter: blur(10px);
    }
    
    .eye-toggle-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        border-color: rgba(255, 255, 255, 0.5);
        color: white;
        transform: scale(1.05);
    }
    
    .modern-dropdown {
        position: relative;
    }
    
    .dropdown-toggle-modern {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.3);
        color: white;
        padding: 12px 20px;
        border-radius: 12px;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s ease;
        backdrop-filter: blur(10px);
        font-weight: 600;
    }
    
    .dropdown-toggle-modern:hover {
        background: rgba(255, 255, 255, 0.3);
        border-color: rgba(255, 255, 255, 0.5);
        color: white;
        transform: scale(1.05);
    }
    
    .dropdown-menu-modern {
        background: white;
        border: none;
        border-radius: 16px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        padding: 15px;
        min-width: 280px;
        margin-top: 10px;
    }
    
    .dropdown-item-modern {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 15px 20px;
        border-radius: 12px;
        color: #374151;
        text-decoration: none;
        transition: all 0.3s ease;
        margin-bottom: 8px;
        font-weight: 500;
    }
    
    .dropdown-item-modern:hover {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        color: white;
        transform: translateX(5px);
    }
    
    .dropdown-item-modern i {
        font-size: 1.2rem;
        width: 20px;
    }
    
    .keys-card-body {
        padding: 30px;
    }
    
    .table-modern {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .table-modern table {
        margin: 0;
        border: none;
    }
    
    .table-modern thead th {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 20px 15px;
        font-weight: 600;
        font-size: 0.95rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .table-modern tbody td {
        border: none;
        padding: 18px 15px;
        border-bottom: 1px solid #F3F4F6;
        vertical-align: middle;
    }
    
    .table-modern tbody tr:hover {
        background: #F9FAFB;
    }
    
    .table-modern tbody tr:last-child td {
        border-bottom: none;
    }
    
    .action-buttons {
        display: flex;
        gap: 8px;
        justify-content: center;
    }
    
    .btn-modern {
        padding: 8px 12px;
        border-radius: 8px;
        border: none;
        font-size: 0.9rem;
        font-weight: 600;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 40px;
        height: 40px;
    }
    
    .btn-reset {
        background: linear-gradient(135deg, #F59E0B, #D97706);
        color: white;
    }
    
    .btn-reset:hover {
        background: linear-gradient(135deg, #D97706, #B45309);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(245, 158, 11, 0.4);
    }
    
    .btn-delete {
        background: linear-gradient(135deg, #EF4444, #DC2626);
        color: white;
    }
    
    .btn-delete:hover {
        background: linear-gradient(135deg, #DC2626, #B91C1C);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(239, 68, 68, 0.4);
    }
    
    .btn-edit {
        background: linear-gradient(135deg, #3B82F6, #2563EB);
        color: white;
    }
    
    .btn-edit:hover {
        background: linear-gradient(135deg, #2563EB, #1D4ED8);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(59, 130, 246, 0.4);
    }
    
    .key-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }
    
    .badge-success {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
    }
    
    .badge-danger {
        background: linear-gradient(135deg, #EF4444, #DC2626);
        color: white;
    }
    
    .badge-dark {
        background: linear-gradient(135deg, #6B7280, #4B5563);
        color: white;
    }
    
    .badge-primary {
        background: linear-gradient(135deg, #3B82F6, #2563EB);
        color: white;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #6B7280;
    }
    
    .empty-state i {
        font-size: 4rem;
        color: #D1D5DB;
        margin-bottom: 20px;
    }
    
    .empty-state h3 {
        color: #374151;
        margin-bottom: 10px;
    }
    
    .key-sensi {
        filter: blur(3px);
        transition: filter 0.3s ease;
    }
    
    @media (max-width: 768px) {
        .keys-container {
            padding: 15px;
        }
        
        .keys-title {
            font-size: 2rem;
        }
        
        .keys-card-header {
            flex-direction: column;
            gap: 15px;
            text-align: center;
        }
        
        .header-actions {
            justify-content: center;
        }
        
        .action-buttons {
            flex-direction: column;
            gap: 5px;
        }
        
        .btn-modern {
            width: 100%;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="keys-container">
    <!-- Keys Header -->
    <div class="keys-header">
        <h1 class="keys-title">Keys Management</h1>
        <p class="keys-subtitle">Manage and monitor your registered keys</p>
    </div>
    
    <!-- Status Messages -->
    <div class="row">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>
    
    <!-- Keys Card -->
    <div class="keys-card">
        <div class="keys-card-header">
            <h2 class="keys-card-title">
                <i class="bi bi-key-fill"></i>
                Keys Registered
            </h2>
            <div class="header-actions">
                <button class="btn eye-toggle-btn" id="blur-out" data-bs-toggle="tooltip" data-bs-placement="top" title="Toggle Key Visibility">
                    <i class="bi bi-eye-slash"></i>
                </button>
                
                <div class="modern-dropdown">
                    <a class="dropdown-toggle-modern" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-three-dots-vertical"></i>
                        Actions
                    </a>
                    <ul class="dropdown-menu dropdown-menu-modern" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item-modern" href="<?= site_url('keys/generate') ?>">
                            <i class="bi bi-plus-circle-fill" style="color: #10B981;"></i>
                            Generate New Key
                        </a>
                        <a class="dropdown-item-modern" href="<?= site_url('keys/deleteExp') ?>">
                            <i class="bi bi-trash-fill" style="color: #EF4444;"></i>
                            Delete Expired Keys
                        </a>
                        <a class="dropdown-item-modern" href="<?= site_url('keys/deleteUnused') ?>">
                            <i class="bi bi-box-fill" style="color: #F59E0B;"></i>
                            Delete Unused Keys
                        </a>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="keys-card-body">
            <?php if ($keylist) : ?>
                <div class="table-modern">
                    <div class="table-responsive">
                        <table id="datatable" class="table table-hover text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Game</th>
                                    <th>User Keys</th>
                                    <th>Devices</th>
                                    <th>Duration</th>
                                    <th>Expired</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            <?php else : ?>
                <div class="empty-state">
                    <i class="bi bi-key"></i>
                    <h3>No Keys Found</h3>
                    <p>There are no keys to display at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>

<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [
                [0, "desc"]
            ],
            ajax: "<?= site_url('keys/api') ?>",
            columns: [{
                    data: 'id',
                    name: 'id_keys'
                },
                {
                    data: 'game',
                },
                {
                    data: 'user_key',
                    render: function(data, type, row, meta) {
                        var is_valid = (row.status == 'Active') ? "badge-success" : "badge-danger";
                        return `<span class="key-badge ${is_valid} keyBlur key-sensi">${(row.user_key ? row.user_key : '&mdash;')}</span>`;
                    }
                },
                {
                    data: 'devices',
                    render: function(data, type, row, meta) {
                        var totalDevice = (row.devices ? row.devices : 0);
                        return `<span id="devMax-${row.user_key}">${totalDevice}/${row.max_devices}</span>`;
                    }
                },
                {
                    data: 'duration',
                    render: function(data, type, row, meta) {
                        return row.duration;
                    }
                },
                {
                    data: 'expired',
                    name: 'expired_date',
                    render: function(data, type, row, meta) {
                        return row.expired ? `<span class="key-badge badge-dark">${row.expired}</span>` : '<span class="text-muted">(not started yet)</span>';
                    }
                },
                {
                    data: null,
                    render: function(data, type, row, meta) {
                        var btnReset = `<button class="btn-modern btn-reset" onclick="resetUserKey('${row.user_key}')"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="Reset key?"><i class="bi bi-bootstrap-reboot"></i></button>`;
                        var btnalterOne = `<button class="btn-modern btn-delete" onclick="resetUserKey1('${row.user_key}')"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="DELETE KEY?"><i class="bi bi-trash-fill"></i></button>`;
                        var btnEdits = `<a href="${window.location.origin}/keys/${row.id}" class="btn-modern btn-edit"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="Edit key information?"><i class="bi bi-pencil-square"></i></a>`;
                        return `<div class="action-buttons">${btnReset} ${btnalterOne} ${btnEdits}</div>`;
                    }
                }
            ]
        });

        $("#blur-out").click(function() {
            if ($(".keyBlur").hasClass("key-sensi")) {
                $(".keyBlur").removeClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye"></i>`);
            } else {
                $(".keyBlur").addClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye-slash"></i>`);
            }
        });
    });
    function resetUserKey1(keys) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Delete'
        }).then((result) => {
            if (result.isConfirmed) {
                Toast.fire({
                    icon: 'info',
                    title: 'Please wait...'
                })

                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/resetAll`;
                $.getJSON(api_url, {
                        userkey: keys,
                        reset: 1
                    },
                    function(data, textStatus, jqXHR) {
                        if (textStatus == 'success') {
                            if (data.registered) {
                                if (data.reset) {
                                    $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
                                    Swal.fire(
                                        'Reset!',
                                        'Your device key has been reset.',
                                        'success'
                                    )
                                } else {
                                    Swal.fire(
                                        'Failed!',
                                        data.devices_total ? "You don't have any access to this user." : "User key devices already reset.",
                                        data.devices_total ? 'error' : 'warning'
                                    )
                                }
                            } else {
                                Swal.fire(
                                    'Failed!',
                                    "User key no longer exists.",
                                    'error'
                                )
                            }
                        }
                    }
                );
            }
        });
    }
    function resetUserKey(keys) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, reset'
        }).then((result) => {
            if (result.isConfirmed) {
                Toast.fire({
                    icon: 'info',
                    title: 'Please wait...'
                })

                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/reset`;
                $.getJSON(api_url, {
                        userkey: keys,
                        reset: 1
                    },
                    function(data, textStatus, jqXHR) {
                        if (textStatus == 'success') {
                            if (data.registered) {
                                if (data.reset) {
                                    $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
                                    Swal.fire(
                                        'Reset!',
                                        'Your device key has been reset.',
                                        'success'
                                    )
                                } else {
                                    Swal.fire(
                                        'Failed!',
                                        data.devices_total ? "You don't have any access to this user." : "User key devices already reset.",
                                        data.devices_total ? 'error' : 'warning'
                                    )
                                }
                            } else {
                                Swal.fire(
                                    'Failed!',
                                    "User key no longer exists.",
                                    'error'
                                )
                            }
                        }
                    }
                );
            }
        });
    }
</script>

<?= $this->endSection() ?>