<?php

function color($value) {
if($value == 1) {
return "#0000FF";
} else {
return "#FF0000";
}
}
?>


<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .users-container {
        padding: 20px;
        min-height: 100vh;
    }
    
    .users-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
    }
    
    .users-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .users-subtitle {
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    .info-alert {
        background: linear-gradient(135deg, #3B82F6, #2563EB);
        color: white;
        padding: 20px;
        border-radius: 16px;
        margin-bottom: 25px;
        box-shadow: 0 8px 25px rgba(59, 130, 246, 0.3);
        border: none;
    }
    
    .info-alert i {
        margin-right: 10px;
        font-size: 1.2rem;
    }
    
    .users-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        margin-bottom: 30px;
    }
    
    .users-card-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 25px 30px;
        font-size: 1.5rem;
        font-weight: 600;
        display: flex;
        align-items: center;
    }
    
    .users-card-header i {
        margin-right: 12px;
        font-size: 1.8rem;
    }
    
    .users-card-body {
        padding: 30px;
    }
    
    .table-modern {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .table-modern table {
        margin: 0;
        border: none;
    }
    
    .table-modern thead th {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 20px 15px;
        font-weight: 600;
        font-size: 0.95rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .table-modern tbody td {
        border: none;
        padding: 18px 15px;
        border-bottom: 1px solid #F3F4F6;
        vertical-align: middle;
    }
    
    .table-modern tbody tr:hover {
        background: #F9FAFB;
    }
    
    .table-modern tbody tr:last-child td {
        border-bottom: none;
    }
    
    .user-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .badge-owner {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        color: white;
    }
    
    .badge-admin {
        background: linear-gradient(135deg, #3B82F6, #2563EB);
        color: white;
    }
    
    .badge-reseller {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
    }
    
    .status-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }
    
    .status-active {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
    }
    
    .status-banned {
        background: linear-gradient(135deg, #EF4444, #DC2626);
        color: white;
    }
    
    .status-expired {
        background: linear-gradient(135deg, #F59E0B, #D97706);
        color: white;
    }
    
    .action-btn {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        color: white;
        border: none;
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 0.9rem;
        font-weight: 600;
        transition: all 0.3s ease;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 40px;
        height: 40px;
    }
    
    .action-btn:hover {
        background: linear-gradient(135deg, #7C3AED, #6D28D9);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(139, 92, 246, 0.4);
    }
    
    .user-id {
        font-weight: 700;
        color: #8B5CF6;
        font-size: 1.1rem;
    }
    
    .username {
        font-weight: 600;
        color: #374151;
    }
    
    .fullname {
        color: #6B7280;
        font-style: italic;
    }
    
    .saldo {
        font-weight: 600;
        color: #059669;
    }
    
    .uplink {
        color: #6B7280;
        font-family: 'Courier New', monospace;
        font-size: 0.9rem;
    }
    
    .expiration {
        color: #6B7280;
        font-size: 0.9rem;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #6B7280;
    }
    
    .empty-state i {
        font-size: 4rem;
        color: #D1D5DB;
        margin-bottom: 20px;
    }
    
    .empty-state h3 {
        color: #374151;
        margin-bottom: 10px;
    }
    
    @media (max-width: 768px) {
        .users-container {
            padding: 15px;
        }
        
        .users-title {
            font-size: 2rem;
        }
        
        .users-card-body {
            padding: 20px;
        }
        
        .table-modern {
            font-size: 0.9rem;
        }
        
        .table-modern thead th,
        .table-modern tbody td {
            padding: 12px 8px;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="users-container">
    <!-- Users Header -->
    <div class="users-header">
        <h1 class="users-title">User Management</h1>
        <p class="users-subtitle">Manage and monitor all system users</p>
    </div>
    
    <!-- Info Alert -->
    <div class="info-alert">
        <i class="bi bi-info-circle-fill"></i>
        <strong>Search Information:</strong> You can search for specific users by their username, fullname, saldo, or uplink.
    </div>
    
    <!-- Users Card -->
    <div class="users-card">
        <div class="users-card-header">
            <i class="bi bi-people-fill"></i>
            Manage Users
        </div>
        <div class="users-card-body">
            <?php if ($user_list) : ?>
                <div class="table-modern">
                    <div class="table-responsive">
                        <table class="table table-hover text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Fullname</th>
                                    <th>Level</th>
                                    <th>Saldo</th>
                                    <th>Status</th>
                                    <th>Uplink</th>
                                    <th>Expiration</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($user_list as $u) : ?>
                                <tr>
                                    <td><span class="user-id">#<?= $u->id_users ?></span></td>
                                    <td><span class="username"><?= $u->username ?></span></td>
                                    <td><span class="fullname"><?= $u->fullname ?></span></td>
                                    <td>
                                        <?php if($u->level == 1) : ?>
                                            <span class="user-badge badge-owner">Owner</span>
                                        <?php elseif($u->level == 2) : ?>
                                            <span class="user-badge badge-admin">Admin</span>
                                        <?php else : ?>
                                            <span class="user-badge badge-reseller">Reseller</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($u->level == 1) : ?>
                                            <span class="saldo">∞</span>
                                        <?php else : ?>
                                            <span class="saldo">₹<?= $u->saldo ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($u->status == 1) : ?>
                                            <span class="status-badge status-active">Active</span>
                                        <?php elseif($u->status == 2) : ?>
                                            <span class="status-badge status-banned">Banned</span>
                                        <?php else : ?>
                                            <span class="status-badge status-expired">Expired</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="uplink"><?= $u->uplink ?></span></td>
                                    <td><span class="expiration"><?= $u->expiration_date ?></span></td>
                                    <td>
                                        <a href="user/<?php echo $u->id_users ?>" class="action-btn" title="Edit User">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else : ?>
                <div class="empty-state">
                    <i class="bi bi-people"></i>
                    <h3>No Users Found</h3>
                    <p>There are no users to display at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
    $(document).ready(function() {
        $('.table').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[0, 'desc']],
            language: {
                search: "Search users:",
                lengthMenu: "Show _MENU_ users per page",
                info: "Showing _START_ to _END_ of _TOTAL_ users",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            }
        });
    });
</script>
<?= $this->endSection() ?>