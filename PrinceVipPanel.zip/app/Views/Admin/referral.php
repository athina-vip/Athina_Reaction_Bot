<?php
include('conn.php');
include('mail.php');

// For Highest id Ref
$sqli = "SELECT * FROM referral_code
ORDER BY id_reff DESC
LIMIT 1;";
$result = mysqli_query($conn, $sqli);
$id_reff = mysqli_fetch_assoc($result);

// For Referral Code
$sql = "SELECT Referral FROM referral_code";
$result = mysqli_query($conn, $sql);
$refcode = mysqli_fetch_assoc($result);
$row = $refcode;

?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .referral-container {
        padding: 20px;
        min-height: 100vh;
    }
    
    .referral-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
    }
    
    .referral-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .referral-subtitle {
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    .referral-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        margin-bottom: 30px;
        transition: all 0.3s ease;
    }
    
    .referral-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }
    
    .referral-card-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 25px 30px;
        font-size: 1.3rem;
        font-weight: 600;
        display: flex;
        align-items: center;
    }
    
    .referral-card-header i {
        margin-right: 12px;
        font-size: 1.5rem;
    }
    
    .referral-card-body {
        padding: 30px;
    }
    
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-label {
        font-weight: 600;
        color: #374151;
        margin-bottom: 8px;
        display: block;
    }
    
    .form-control, .form-select {
        width: 100%;
        padding: 15px 20px;
        border: 2px solid #E5E7EB;
        border-radius: 12px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #F9FAFB;
    }
    
    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: #8B5CF6;
        background: white;
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
    }
    
    .input-group {
        position: relative;
    }
    
    .input-group-text {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        color: white;
        border: 2px solid #8B5CF6;
        border-right: none;
        border-radius: 12px 0 0 12px;
        padding: 15px 20px;
        font-size: 1.1rem;
    }
    
    .input-group .form-control {
        border-left: none;
        border-radius: 0 12px 12px 0;
    }
    
    .input-group .form-control:focus {
        border-left: none;
    }
    
    .create-btn {
        width: 100%;
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 18px;
        border-radius: 12px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }
    
    .create-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(139, 92, 246, 0.3);
    }
    
    .table-modern {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .table-modern table {
        margin: 0;
        border: none;
    }
    
    .table-modern thead th {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 20px 15px;
        font-weight: 600;
        font-size: 0.95rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .table-modern tbody td {
        border: none;
        padding: 18px 15px;
        border-bottom: 1px solid #F3F4F6;
        vertical-align: middle;
    }
    
    .table-modern tbody tr:hover {
        background: #F9FAFB;
    }
    
    .table-modern tbody tr:last-child td {
        border-bottom: none;
    }
    
    .referral-id {
        font-weight: 700;
        color: #8B5CF6;
        font-size: 1.1rem;
    }
    
    .referral-code {
        font-family: 'Courier New', monospace;
        font-weight: 600;
        color: #374151;
        background: #F3F4F6;
        padding: 4px 8px;
        border-radius: 6px;
        font-size: 0.9rem;
    }
    
    .hashed-code {
        font-family: 'Courier New', monospace;
        color: #6B7280;
        font-size: 0.85rem;
        background: #F9FAFB;
        padding: 4px 8px;
        border-radius: 6px;
    }
    
    .saldo-amount {
        font-weight: 600;
        color: #059669;
        font-size: 1.1rem;
    }
    
    .level-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .level-owner {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        color: white;
    }
    
    .level-admin {
        background: linear-gradient(135deg, #3B82F6, #2563EB);
        color: white;
    }
    
    .level-reseller {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
    }
    
    .expiration-date {
        color: #6B7280;
        font-size: 0.9rem;
    }
    
    .used-by {
        color: #374151;
        font-weight: 500;
    }
    
    .created-by {
        color: #6B7280;
        font-style: italic;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #6B7280;
    }
    
    .empty-state i {
        font-size: 4rem;
        color: #D1D5DB;
        margin-bottom: 20px;
    }
    
    .empty-state h3 {
        color: #374151;
        margin-bottom: 10px;
    }
    
    .error-message {
        color: #EF4444;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
    }
    
    .total-badge {
        background: rgba(255, 255, 255, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.9rem;
        font-weight: 600;
        margin-left: 10px;
    }
    
    @media (max-width: 768px) {
        .referral-container {
            padding: 15px;
        }
        
        .referral-title {
            font-size: 2rem;
        }
        
        .referral-card-body {
            padding: 20px;
        }
        
        .table-modern {
            font-size: 0.9rem;
        }
        
        .table-modern thead th,
        .table-modern tbody td {
            padding: 12px 8px;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="referral-container">
    <!-- Referral Header -->
    <div class="referral-header">
        <h1 class="referral-title">Referral Management</h1>
        <p class="referral-subtitle">Generate and manage referral codes for user registration</p>
    </div>
    
    <!-- Status Messages -->
    <div class="row">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>
    
    <div class="row">
        <!-- Generate Referral Code Card -->
        <div class="col-lg-4">
            <div class="referral-card">
                <div class="referral-card-header">
                    <i class="bi bi-plus-circle-fill"></i>
                    Generate <?= $title ?>
                </div>
                <div class="referral-card-body">
                    <?= form_open() ?>
                    
                    <div class="form-group">
                        <label for="set_saldo" class="form-label">Referral Bonus Amount</label>
                        <p class="text-muted small mb-3">You can set with multiple saldo amounts</p>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bi bi-currency-rupee"></i>
                            </span>
                            <input type="number" class="form-control" name="set_saldo" id="set_saldo" min="1" max="999999" value="5" required>
                        </div>
                        <?php if ($validation->hasError('set_saldo')) : ?>
                            <span class="error-message"><?= $validation->getError('set_saldo') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="accExpire" class="form-label">Account Expiration</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'accExpire', 'id' => 'accExpire'], $accExpire, old('accExpire') ?: '') ?>
                        <?php if ($validation->hasError('accExpire')) : ?>
                            <span class="error-message"><?= $validation->getError('accExpire') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="accLevel" class="form-label">Account Level</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'accLevel', 'id' => 'accLevel'], $accLevel, old('accLevel') ?: '') ?>
                        <?php if ($validation->hasError('accLevel')) : ?>
                            <span class="error-message"><?= $validation->getError('accLevel') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="create-btn">
                        <i class="bi bi-key-fill"></i>
                        Create Referral Code
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
        
        <!-- Referral History Card -->
        <div class="col-lg-8">
            <?php if ($code) : ?>
                <div class="referral-card">
                    <div class="referral-card-header">
                        <i class="bi bi-clock-history"></i>
                        Referral History
                        <span class="total-badge">Total: <?= $total_code ?></span>
                    </div>
                    <div class="referral-card-body">
                        <div class="table-modern">
                            <div class="table-responsive">
                                <table class="table table-hover text-center" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Referral</th>
                                            <th>Hashed</th>
                                            <th>Saldo</th>
                                            <th>Level</th>
                                            <th>Expiration</th>
                                            <th>Used by</th>
                                            <th>Created by</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($code as $c) : ?>
                                            <tr>
                                                <td><span class="referral-id">#<?= $c->id_reff ?></span></td>
                                                <td><span class="referral-code"><?= $c->Referral ?></span></td>
                                                <td><span class="hashed-code"><?= substr($c->code, 1, 15) ?>...</span></td>
                                                <td><span class="saldo-amount">₹<?= $c->set_saldo ?></span></td>
                                                <td>
                                                    <?php if($c->level == 1) : ?>
                                                        <span class="level-badge level-owner">Owner</span>
                                                    <?php elseif($c->level == 2) : ?>
                                                        <span class="level-badge level-admin">Admin</span>
                                                    <?php else : ?>
                                                        <span class="level-badge level-reseller">Reseller</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><span class="expiration-date"><?= $c->acc_expiration ?></span></td>
                                                <td><span class="used-by"><?= $c->used_by ?: 'Not Used' ?></span></td>
                                                <td><span class="created-by"><?= $c->created_by ?></span></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else : ?>
                <div class="referral-card">
                    <div class="referral-card-header">
                        <i class="bi bi-clock-history"></i>
                        Referral History
                    </div>
                    <div class="referral-card-body">
                        <div class="empty-state">
                            <i class="bi bi-link-45deg"></i>
                            <h3>No Referral Codes</h3>
                            <p>No referral codes have been generated yet.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>