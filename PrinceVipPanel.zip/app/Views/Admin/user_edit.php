<?php
include('mail.php');
?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .user-edit-container {
        padding: 20px;
        min-height: 100vh;
    }
    
    .user-edit-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
    }
    
    .user-edit-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .user-edit-subtitle {
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    .user-edit-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        margin-bottom: 30px;
        transition: all 0.3s ease;
    }
    
    .user-edit-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }
    
    .user-edit-card-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 25px 30px;
        font-size: 1.3rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .user-edit-card-header i {
        margin-right: 12px;
        font-size: 1.5rem;
    }
    
    .back-btn {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.3);
        color: white;
        padding: 8px 16px;
        border-radius: 10px;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s ease;
        font-size: 0.9rem;
        font-weight: 500;
    }
    
    .back-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        color: white;
        transform: translateX(-3px);
    }
    
    .user-edit-card-body {
        padding: 40px;
    }
    
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-label {
        font-weight: 600;
        color: #374151;
        margin-bottom: 8px;
        display: block;
        font-size: 0.95rem;
    }
    
    .form-control, .form-select {
        width: 100%;
        padding: 15px 20px;
        border: 2px solid #E5E7EB;
        border-radius: 12px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #F9FAFB;
    }
    
    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: #8B5CF6;
        background: white;
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
    }
    
    .form-control::placeholder {
        color: #9CA3AF;
        font-style: italic;
    }
    
    .input-group {
        position: relative;
    }
    
    .input-group-text {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        color: white;
        border: 2px solid #8B5CF6;
        border-right: none;
        border-radius: 12px 0 0 12px;
        padding: 15px 20px;
        font-size: 1.1rem;
    }
    
    .input-group .form-control {
        border-left: none;
        border-radius: 0 12px 12px 0;
    }
    
    .input-group .form-control:focus {
        border-left: none;
    }
    
    .update-btn {
        width: 100%;
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 18px;
        border-radius: 12px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        margin-top: 20px;
    }
    
    .update-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(139, 92, 246, 0.3);
    }
    
    .error-message {
        color: #EF4444;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
        font-weight: 500;
    }
    
    .form-row {
        display: flex;
        gap: 20px;
        margin-bottom: 25px;
    }
    
    .form-col {
        flex: 1;
    }
    
    .user-info-badge {
        background: rgba(255, 255, 255, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.9rem;
        font-weight: 600;
        margin-left: 10px;
    }
    
    .field-icon {
        color: #8B5CF6;
        margin-right: 8px;
        font-size: 1.1rem;
    }
    
    .form-section {
        margin-bottom: 30px;
    }
    
    .form-section-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: #374151;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #E5E7EB;
        display: flex;
        align-items: center;
    }
    
    .form-section-title i {
        margin-right: 10px;
        color: #8B5CF6;
    }
    
    @media (max-width: 768px) {
        .user-edit-container {
            padding: 15px;
        }
        
        .user-edit-title {
            font-size: 2rem;
        }
        
        .user-edit-card-body {
            padding: 25px;
        }
        
        .form-row {
            flex-direction: column;
            gap: 0;
        }
        
        .user-edit-card-header {
            flex-direction: column;
            gap: 15px;
            text-align: center;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="user-edit-container">
    <!-- User Edit Header -->
    <div class="user-edit-header">
        <h1 class="user-edit-title">Edit User Account</h1>
        <p class="user-edit-subtitle">Update account information and settings for <?= getName($target) ?></p>
    </div>
    
    <!-- Status Messages -->
    <div class="row">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>
    
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="user-edit-card">
                <div class="user-edit-card-header">
                    <div>
                        <i class="bi bi-person-gear"></i>
                        Account Information
                        <span class="user-info-badge"><?= getName($target) ?></span>
                    </div>
                    <a href="<?= site_url('admin/manage-users') ?>" class="back-btn">
                        <i class="bi bi-arrow-left"></i>
                        Back to Users
                    </a>
                </div>
                <div class="user-edit-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="user_id" value="<?= $target->id_users ?>">
                    
                    <!-- Personal Information Section -->
                    <div class="form-section">
                        <div class="form-section-title">
                            <i class="bi bi-person-fill"></i>
                            Personal Information
                        </div>
                        <div class="form-row">
                            <div class="form-col">
                                <div class="form-group">
                                    <label for="username" class="form-label">
                                        <i class="bi bi-person field-icon"></i>
                                        Username
                                    </label>
                                    <input type="text" name="username" id="username" class="form-control" placeholder="Enter username" value="<?= old('username') ?: $target->username ?>">
                                    <?php if ($validation->hasError('username')) : ?>
                                        <span class="error-message"><?= $validation->getError('username') ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-col">
                                <div class="form-group">
                                    <label for="fullname" class="form-label">
                                        <i class="bi bi-person-badge field-icon"></i>
                                        Full Name
                                    </label>
                                    <input type="text" name="fullname" id="fullname" class="form-control" placeholder="Enter full name" value="<?= old('fullname') ?: $target->fullname ?>">
                                    <?php if ($validation->hasError('fullname')) : ?>
                                        <span class="error-message"><?= $validation->getError('fullname') ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Account Settings Section -->
                    <div class="form-section">
                        <div class="form-section-title">
                            <i class="bi bi-gear-fill"></i>
                            Account Settings
                        </div>
                        <div class="form-row">
                            <div class="form-col">
                                <div class="form-group">
                                    <label for="level" class="form-label">
                                        <i class="bi bi-shield-check field-icon"></i>
                                        User Role
                                    </label>
                                    <?php $sel_level = ['' => '— Select Role —', '1' => 'Owner', '2' => 'Admin', '3' => 'Reseller']; ?>
                                    <?= form_dropdown(['class' => 'form-select', 'name' => 'level', 'id' => 'level'], $sel_level, $target->level) ?>
                                </div>
                            </div>
                            <div class="form-col">
                                <div class="form-group">
                                    <label for="status" class="form-label">
                                        <i class="bi bi-toggle-on field-icon"></i>
                                        Account Status
                                    </label>
                                    <?php $sel_status = ['' => '— Select Status —', '2' => 'Banned/Blocked', '1' => 'Active', '3' => 'Expired']; ?>
                                    <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, $target->status) ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Financial Information Section -->
                    <div class="form-section">
                        <div class="form-section-title">
                            <i class="bi bi-currency-rupee"></i>
                            Financial Information
                        </div>
                        <div class="form-row">
                            <div class="form-col">
                                <div class="form-group">
                                    <label for="saldo" class="form-label">
                                        <i class="bi bi-wallet2 field-icon"></i>
                                        Account Balance
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-currency-rupee"></i>
                                        </span>
                                        <input type="number" name="saldo" id="saldo" class="form-control" placeholder="Enter balance amount" value="<?= old('saldo') ?: $target->saldo ?>">
                                    </div>
                                    <?php if ($validation->hasError('saldo')) : ?>
                                        <span class="error-message"><?= $validation->getError('saldo') ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-col">
                                <div class="form-group">
                                    <label for="uplink" class="form-label">
                                        <i class="bi bi-link-45deg field-icon"></i>
                                        Uplink
                                    </label>
                                    <input type="text" name="uplink" id="uplink" class="form-control" placeholder="Enter uplink information" value="<?= old('uplink') ?: $target->uplink ?>">
                                    <?php if ($validation->hasError('uplink')) : ?>
                                        <span class="error-message"><?= $validation->getError('uplink') ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Account Expiration Section -->
                    <div class="form-section">
                        <div class="form-section-title">
                            <i class="bi bi-calendar-check field-icon"></i>
                            Account Expiration
                        </div>
                        <div class="form-group">
                            <label for="expiration" class="form-label">
                                <i class="bi bi-calendar-x field-icon"></i>
                                Expiration Date
                            </label>
                            <input type="text" name="expiration" id="expiration" class="form-control" placeholder="Enter expiration date" value="<?= old('expiration') ?: $target->expiration_date ?>">
                            <?php if ($validation->hasError('expiration')) : ?>
                                <span class="error-message"><?= $validation->getError('expiration') ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <button type="submit" class="update-btn">
                        <i class="bi bi-check-circle-fill"></i>
                        Update Account Information
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>